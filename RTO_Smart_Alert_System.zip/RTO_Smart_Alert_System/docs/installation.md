# Installation Guide

This guide provides instructions for setting up the RTO Smart Alert & Parking Safety System development environment.

## Prerequisites

Before you begin, ensure you have the following installed:

- [Node.js](https://nodejs.org/) (v14.x or higher)
- [npm](https://www.npmjs.com/) (v6.x or higher)
- [Python](https://www.python.org/) (v3.8 or higher)
- [Flutter](https://flutter.dev/docs/get-started/install) (for mobile app development)
- [MongoDB](https://www.mongodb.com/try/download/community) (for database)
- [Git](https://git-scm.com/)

## Frontend Setup (Flutter)

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/rto-smart-alert-system.git
   cd rto-smart-alert-system/code/frontend
   ```

2. Install Flutter dependencies:
   ```bash
   flutter pub get
   ```

3. Configure Google Maps API:
   - Create a Google Cloud Platform account and enable Google Maps API
   - Get your API key from the Google Cloud Console
   - Add the API key to `android/app/src/main/AndroidManifest.xml` and `ios/Runner/AppDelegate.swift`

4. Configure Firebase:
   - Create a Firebase project
   - Download `google-services.json` for Android and `GoogleService-Info.plist` for iOS
   - Place these files in the appropriate directories (`android/app/` and `ios/Runner/`)

5. Run the app:
   ```bash
   flutter run
   ```

## Backend Setup (Node.js)

1. Navigate to the backend directory:
   ```bash
   cd rto-smart-alert-system/code/backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   - Create a `.env` file in the backend directory
   - Add the following variables:
     ```
     PORT=3000
     MONGODB_URI=mongodb://localhost:27017/rto_alert_system
     JWT_SECRET=your_jwt_secret
     TWILIO_ACCOUNT_SID=your_twilio_sid
     TWILIO_AUTH_TOKEN=your_twilio_token
     FIREBASE_API_KEY=your_firebase_api_key
     ```

4. Start the server:
   ```bash
   npm start
   ```

## AI Model Setup (Python)

1. Navigate to the AI directory:
   ```bash
   cd rto-smart-alert-system/code/backend/ai
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Download pre-trained YOLOv8 model:
   ```bash
   python download_model.py
   ```

## Database Setup

1. Start MongoDB service:
   ```bash
   sudo systemctl start mongod
   ```

2. Initialize the database:
   ```bash
   cd rto-smart-alert-system/code/backend
   node init-db.js
   ```

## Testing the System

1. Run backend tests:
   ```bash
   cd rto-smart-alert-system/code/backend
   npm test
   ```

2. Run frontend tests:
   ```bash
   cd rto-smart-alert-system/code/frontend
   flutter test
   ```

## Deployment

### Backend Deployment (Using Firebase Functions)

1. Install Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```

2. Login to Firebase:
   ```bash
   firebase login
   ```

3. Initialize Firebase in the backend directory:
   ```bash
   cd rto-smart-alert-system/code/backend
   firebase init functions
   ```

4. Deploy functions:
   ```bash
   firebase deploy --only functions
   ```

### Mobile App Deployment

1. Build the Flutter app for release:
   ```bash
   cd rto-smart-alert-system/code/frontend
   flutter build apk --release  # For Android
   flutter build ios --release  # For iOS
   ```

2. Follow the platform-specific guidelines for publishing:
   - [Android Play Store](https://developer.android.com/studio/publish)
   - [Apple App Store](https://developer.apple.com/ios/submit/)

## Troubleshooting

- **Issue**: Google Maps not displaying
  - **Solution**: Verify that your API key is correctly configured and has the necessary permissions

- **Issue**: Firebase connection errors
  - **Solution**: Check that your Firebase configuration files are correctly placed and the project is properly set up

- **Issue**: MongoDB connection issues
  - **Solution**: Ensure MongoDB service is running and the connection string in `.env` is correct

- **Issue**: YOLOv8 model not working
  - **Solution**: Verify that all dependencies are installed and the model file is downloaded correctly

## Additional Resources

- [Flutter Documentation](https://flutter.dev/docs)
- [Node.js Documentation](https://nodejs.org/en/docs/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [YOLOv8 Documentation](https://docs.ultralytics.com/)
- [Firebase Documentation](https://firebase.google.com/docs)

## Support

For additional help, please contact the development team or open an issue on the GitHub repository.

