# API Documentation

## RTO Smart Alert & Parking Safety System

This document provides detailed information about the API endpoints available in the RTO Smart Alert & Parking Safety System.

## Base URL

```
https://api.rtoalertsystem.com/v1
```

## Authentication

All API requests require authentication using JWT tokens. To authenticate, include the token in the Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

To obtain a token, use the login endpoint.

## Error Handling

The API uses standard HTTP status codes to indicate the success or failure of requests:

- `200 OK`: Request succeeded
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request parameters
- `401 Unauthorized`: Authentication failed
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server-side error

Error responses include a JSON object with details:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {}
  }
}
```

## Rate Limiting

API requests are limited to 100 requests per minute per user. Rate limit information is included in the response headers:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1625097600
```

## API Endpoints

### Authentication

#### Register a new user

```
POST /auth/register
```

**Request Body:**

```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "password": "securePassword123",
  "phone": "+919876543210"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User registered successfully",
  "user": {
    "id": "user123",
    "name": "John Doe",
    "email": "john.doe@example.com"
  }
}
```

#### Login

```
POST /auth/login
```

**Request Body:**

```json
{
  "email": "john.doe@example.com",
  "password": "securePassword123"
}
```

**Response:**

```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "user123",
    "name": "John Doe",
    "email": "john.doe@example.com"
  }
}
```

#### Get user profile

```
GET /auth/profile
```

**Response:**

```json
{
  "id": "user123",
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phone": "+919876543210",
  "preferences": {
    "notificationEnabled": true,
    "smsAlerts": true,
    "alertRadius": 500
  },
  "stats": {
    "reportsSubmitted": 15,
    "reportsVerified": 10,
    "finesAvoided": 3
  }
}
```

#### Update user profile

```
PUT /auth/profile
```

**Request Body:**

```json
{
  "name": "John Smith",
  "preferences": {
    "notificationEnabled": true,
    "smsAlerts": false,
    "alertRadius": 1000
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Profile updated successfully",
  "user": {
    "id": "user123",
    "name": "John Smith",
    "email": "john.doe@example.com",
    "preferences": {
      "notificationEnabled": true,
      "smsAlerts": false,
      "alertRadius": 1000
    }
  }
}
```

### Geospatial API

#### Get nearby parking zones

```
GET /zones/nearby
```

**Query Parameters:**

- `lat` (required): Latitude of the user's location
- `lng` (required): Longitude of the user's location
- `radius` (optional): Search radius in meters (default: 500)
- `types` (optional): Comma-separated list of zone types (legal, illegal, restricted)

**Response:**

```json
{
  "zones": [
    {
      "id": "zone123",
      "type": "legal",
      "coordinates": {
        "lat": 19.0760,
        "lng": 72.8777
      },
      "restrictions": {
        "timeLimit": "2h",
        "days": ["Mon", "Tue", "Wed", "Thu", "Fri"],
        "hours": "9:00-18:00"
      },
      "source": "official",
      "distance": 120
    },
    {
      "id": "zone124",
      "type": "illegal",
      "coordinates": {
        "lat": 19.0765,
        "lng": 72.8780
      },
      "reason": "No parking zone",
      "source": "crowd-sourced",
      "verificationCount": 5,
      "distance": 200
    }
  ],
  "meta": {
    "total": 2,
    "radius": 500
  }
}
```

#### Get zone details

```
GET /zones/details/:id
```

**Path Parameters:**

- `id` (required): Zone identifier

**Response:**

```json
{
  "id": "zone123",
  "type": "legal",
  "coordinates": {
    "lat": 19.0760,
    "lng": 72.8777
  },
  "boundaries": [
    {"lat": 19.0758, "lng": 72.8775},
    {"lat": 19.0758, "lng": 72.8779},
    {"lat": 19.0762, "lng": 72.8779},
    {"lat": 19.0762, "lng": 72.8775}
  ],
  "restrictions": {
    "timeLimit": "2h",
    "days": ["Mon", "Tue", "Wed", "Thu", "Fri"],
    "hours": "9:00-18:00",
    "vehicleTypes": ["car", "motorcycle"]
  },
  "source": "official",
  "lastUpdated": "2023-06-15T10:30:00Z",
  "reports": {
    "incorrect": 2,
    "confirmed": 15
  }
}
```

#### Report a new or incorrect zone

```
POST /zones/report
```

**Request Body:**

```json
{
  "type": "illegal",
  "coordinates": {
    "lat": 19.0770,
    "lng": 72.8785
  },
  "reason": "No parking sign present",
  "image": "base64_encoded_image_data",
  "notes": "Sign indicates no parking between 8 AM and 8 PM"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Zone report submitted successfully",
  "reportId": "report456",
  "status": "pending_verification"
}
```

### RTO Reports API

#### Report an RTO vehicle sighting

```
POST /reports/rto
```

**Request Body:**

```json
{
  "coordinates": {
    "lat": 19.0780,
    "lng": 72.8790
  },
  "vehicleType": "tow_truck",
  "direction": "north",
  "image": "base64_encoded_image_data",
  "notes": "Towing vehicles on the main road"
}
```

**Response:**

```json
{
  "success": true,
  "message": "RTO vehicle report submitted successfully",
  "reportId": "rto789",
  "alertsSent": 5
}
```

#### Get nearby RTO reports

```
GET /reports/nearby
```

**Query Parameters:**

- `lat` (required): Latitude of the user's location
- `lng` (required): Longitude of the user's location
- `radius` (optional): Search radius in meters (default: 1000)
- `timeframe` (optional): Time window in minutes (default: 30)

**Response:**

```json
{
  "reports": [
    {
      "id": "rto789",
      "type": "tow_truck",
      "coordinates": {
        "lat": 19.0780,
        "lng": 72.8790
      },
      "direction": "north",
      "timestamp": "2023-06-15T14:30:00Z",
      "verificationCount": 3,
      "distance": 350,
      "timeElapsed": 10
    },
    {
      "id": "rto790",
      "type": "patrol_car",
      "coordinates": {
        "lat": 19.0790,
        "lng": 72.8795
      },
      "direction": "east",
      "timestamp": "2023-06-15T14:25:00Z",
      "verificationCount": 2,
      "distance": 500,
      "timeElapsed": 15
    }
  ],
  "meta": {
    "total": 2,
    "radius": 1000,
    "timeframe": 30
  }
}
```

#### Verify a report

```
POST /reports/verify/:id
```

**Path Parameters:**

- `id` (required): Report identifier

**Request Body:**

```json
{
  "verified": true,
  "notes": "Confirmed, still present at location"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Report verified successfully",
  "report": {
    "id": "rto789",
    "verificationCount": 4,
    "status": "active"
  }
}
```

### Notification API

#### Update notification preferences

```
POST /notifications/settings
```

**Request Body:**

```json
{
  "pushEnabled": true,
  "smsEnabled": true,
  "alertRadius": 1000,
  "alertTypes": ["rto_vehicle", "illegal_parking", "high_risk_area"],
  "quietHours": {
    "enabled": true,
    "start": "22:00",
    "end": "07:00"
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Notification preferences updated successfully",
  "settings": {
    "pushEnabled": true,
    "smsEnabled": true,
    "alertRadius": 1000,
    "alertTypes": ["rto_vehicle", "illegal_parking", "high_risk_area"],
    "quietHours": {
      "enabled": true,
      "start": "22:00",
      "end": "07:00"
    }
  }
}
```

#### Get notification history

```
GET /notifications/history
```

**Query Parameters:**

- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20)
- `type` (optional): Filter by notification type

**Response:**

```json
{
  "notifications": [
    {
      "id": "notif123",
      "type": "rto_vehicle",
      "message": "RTO tow truck spotted 300m away, heading north on Main Street",
      "coordinates": {
        "lat": 19.0780,
        "lng": 72.8790
      },
      "timestamp": "2023-06-15T14:30:00Z",
      "read": true
    },
    {
      "id": "notif124",
      "type": "illegal_parking",
      "message": "You are parked in a no-parking zone. Please move your vehicle.",
      "coordinates": {
        "lat": 19.0765,
        "lng": 72.8780
      },
      "timestamp": "2023-06-15T13:45:00Z",
      "read": false
    }
  ],
  "meta": {
    "total": 45,
    "page": 1,
    "limit": 20,
    "pages": 3
  }
}
```

#### Send a test notification

```
POST /notifications/test
```

**Request Body:**

```json
{
  "type": "rto_vehicle",
  "channel": "push"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Test notification sent successfully",
  "details": {
    "deliveryStatus": "sent",
    "timestamp": "2023-06-15T15:00:00Z"
  }
}
```

### AI/ML API

#### Process an image for RTO vehicle detection

```
POST /ai/detect
```

**Request Body:**

```json
{
  "image": "base64_encoded_image_data",
  "coordinates": {
    "lat": 19.0780,
    "lng": 72.8790
  },
  "deviceInfo": {
    "model": "iPhone 13",
    "orientation": "landscape"
  }
}
```

**Response:**

```json
{
  "detections": [
    {
      "class": "tow_truck",
      "confidence": 0.92,
      "boundingBox": {
        "x": 120,
        "y": 50,
        "width": 200,
        "height": 150
      }
    },
    {
      "class": "rto_officer",
      "confidence": 0.85,
      "boundingBox": {
        "x": 350,
        "y": 100,
        "width": 100,
        "height": 200
      }
    }
  ],
  "processingTime": 0.45,
  "alertGenerated": true
}
```

#### Get fine probability heatmap for an area

```
GET /ai/heatmap/:area
```

**Path Parameters:**

- `area` (required): Area identifier or coordinates (lat,lng)

**Query Parameters:**

- `resolution` (optional): Heatmap resolution (low, medium, high)
- `timeframe` (optional): Time window in hours (default: 24)

**Response:**

```json
{
  "center": {
    "lat": 19.0760,
    "lng": 72.8777
  },
  "radius": 2000,
  "resolution": "medium",
  "timeframe": 24,
  "heatmapData": [
    {
      "lat": 19.0758,
      "lng": 72.8775,
      "intensity": 0.2
    },
    {
      "lat": 19.0760,
      "lng": 72.8777,
      "intensity": 0.7
    },
    {
      "lat": 19.0762,
      "lng": 72.8779,
      "intensity": 0.5
    }
    // More data points...
  ],
  "hotspots": [
    {
      "lat": 19.0760,
      "lng": 72.8777,
      "radius": 200,
      "intensity": 0.7,
      "peakHours": ["10:00-12:00", "16:00-18:00"]
    }
  ],
  "lastUpdated": "2023-06-15T14:00:00Z"
}
```

### Analytics API (Admin Only)

#### Get system statistics

```
GET /admin/stats
```

**Query Parameters:**

- `period` (optional): Time period (day, week, month)

**Response:**

```json
{
  "users": {
    "total": 5000,
    "active": 3200,
    "new": 120
  },
  "reports": {
    "total": 8500,
    "verified": 7200,
    "rejected": 300
  },
  "notifications": {
    "sent": 12000,
    "delivered": 11500,
    "clicked": 4200
  },
  "zones": {
    "legal": 1200,
    "illegal": 800,
    "restricted": 400
  },
  "detections": {
    "total": 3500,
    "accurate": 3200,
    "falsePositive": 300
  },
  "period": "week",
  "lastUpdated": "2023-06-15T15:00:00Z"
}
```

## Webhooks

The API supports webhooks for real-time event notifications. To register a webhook:

```
POST /webhooks/register
```

**Request Body:**

```json
{
  "url": "https://your-server.com/webhook",
  "events": ["rto_report", "zone_update", "high_risk_alert"],
  "secret": "your_webhook_secret"
}
```

**Response:**

```json
{
  "success": true,
  "webhookId": "webhook123",
  "events": ["rto_report", "zone_update", "high_risk_alert"]
}
```

## Batch Operations

For efficiency, the API supports batch operations:

```
POST /batch
```

**Request Body:**

```json
{
  "operations": [
    {
      "method": "GET",
      "path": "/zones/nearby",
      "params": {
        "lat": 19.0760,
        "lng": 72.8777,
        "radius": 500
      }
    },
    {
      "method": "GET",
      "path": "/reports/nearby",
      "params": {
        "lat": 19.0760,
        "lng": 72.8777,
        "radius": 1000
      }
    }
  ]
}
```

**Response:**

```json
{
  "results": [
    {
      "status": 200,
      "body": {
        "zones": [
          // Zone data...
        ]
      }
    },
    {
      "status": 200,
      "body": {
        "reports": [
          // Report data...
        ]
      }
    }
  ]
}
```

## API Versioning

The API uses URL versioning. The current version is `v1`. When a new version is released, the previous version will be supported for at least 6 months.

## SDK Support

Official SDKs are available for:

- JavaScript/TypeScript
- Flutter/Dart
- Java/Kotlin (Android)
- Swift (iOS)

## Rate Limits and Quotas

- Standard users: 100 requests per minute
- Premium users: 300 requests per minute
- Image processing: 50 requests per day (standard), 200 requests per day (premium)
- Heatmap generation: 10 requests per day (standard), 50 requests per day (premium)

## Support

For API support, please contact:

- Email: api-support@rtoalertsystem.com
- Documentation: https://docs.rtoalertsystem.com
- Status page: https://status.rtoalertsystem.com

