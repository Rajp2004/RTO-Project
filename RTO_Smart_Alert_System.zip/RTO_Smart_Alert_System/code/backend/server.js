const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const admin = require('firebase-admin');
const twilio = require('twilio');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/rto_alert_system', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Firebase Admin SDK initialization
const serviceAccount = require('./firebase-service-account.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// Twilio client
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },
  preferences: {
    notificationEnabled: { type: Boolean, default: true },
    smsAlerts: { type: Boolean, default: true },
    alertRadius: { type: Number, default: 500 },
  },
  stats: {
    reportsSubmitted: { type: Number, default: 0 },
    reportsVerified: { type: Number, default: 0 },
    finesAvoided: { type: Number, default: 0 },
  },
  createdAt: { type: Date, default: Date.now },
});

// Parking Zone Schema
const parkingZoneSchema = new mongoose.Schema({
  type: { type: String, enum: ['legal', 'illegal', 'restricted'], required: true },
  coordinates: {
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
  },
  boundaries: [{
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
  }],
  restrictions: {
    timeLimit: String,
    days: [String],
    hours: String,
    vehicleTypes: [String],
  },
  source: { type: String, enum: ['official', 'crowd-sourced'], default: 'crowd-sourced' },
  verificationCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

// RTO Report Schema
const rtoReportSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  coordinates: {
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
  },
  vehicleType: { type: String, enum: ['patrol_car', 'tow_truck', 'motorcycle'], required: true },
  direction: String,
  image: String, // Base64 encoded image
  notes: String,
  verificationCount: { type: Number, default: 0 },
  status: { type: String, enum: ['active', 'expired', 'verified'], default: 'active' },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: () => new Date(Date.now() + 30 * 60 * 1000) }, // 30 minutes
});

// Models
const User = mongoose.model('User', userSchema);
const ParkingZone = mongoose.model('ParkingZone', parkingZoneSchema);
const RTOReport = mongoose.model('RTOReport', rtoReportSchema);

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Routes

// Authentication Routes
app.post('/auth/register', async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;
    
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      name,
      email,
      password: hashedPassword,
      phone,
    });

    await user.save();

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Geospatial Routes
app.get('/zones/nearby', async (req, res) => {
  try {
    const { lat, lng, radius = 500, types } = req.query;
    
    if (!lat || !lng) {
      return res.status(400).json({ error: 'Latitude and longitude are required' });
    }

    const query = {
      'coordinates.lat': {
        $gte: parseFloat(lat) - (radius / 111000),
        $lte: parseFloat(lat) + (radius / 111000),
      },
      'coordinates.lng': {
        $gte: parseFloat(lng) - (radius / (111000 * Math.cos(parseFloat(lat) * Math.PI / 180))),
        $lte: parseFloat(lng) + (radius / (111000 * Math.cos(parseFloat(lat) * Math.PI / 180))),
      },
    };

    if (types) {
      query.type = { $in: types.split(',') };
    }

    const zones = await ParkingZone.find(query);
    
    res.json({
      zones: zones.map(zone => ({
        ...zone.toObject(),
        distance: calculateDistance(lat, lng, zone.coordinates.lat, zone.coordinates.lng),
      })),
      meta: {
        total: zones.length,
        radius: parseInt(radius),
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// RTO Report Routes
app.post('/reports/rto', authenticateToken, async (req, res) => {
  try {
    const { coordinates, vehicleType, direction, image, notes } = req.body;
    
    const report = new RTOReport({
      userId: req.user.userId,
      coordinates,
      vehicleType,
      direction,
      image,
      notes,
    });

    await report.save();

    // Update user stats
    await User.findByIdAndUpdate(req.user.userId, {
      $inc: { 'stats.reportsSubmitted': 1 },
    });

    // Send alerts to nearby users
    const alertsSent = await sendNearbyAlerts(coordinates, vehicleType);

    res.status(201).json({
      success: true,
      message: 'RTO vehicle report submitted successfully',
      reportId: report._id,
      alertsSent,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/reports/nearby', async (req, res) => {
  try {
    const { lat, lng, radius = 1000, timeframe = 30 } = req.query;
    
    if (!lat || !lng) {
      return res.status(400).json({ error: 'Latitude and longitude are required' });
    }

    const timeThreshold = new Date(Date.now() - timeframe * 60 * 1000);
    
    const reports = await RTOReport.find({
      'coordinates.lat': {
        $gte: parseFloat(lat) - (radius / 111000),
        $lte: parseFloat(lat) + (radius / 111000),
      },
      'coordinates.lng': {
        $gte: parseFloat(lng) - (radius / (111000 * Math.cos(parseFloat(lat) * Math.PI / 180))),
        $lte: parseFloat(lng) + (radius / (111000 * Math.cos(parseFloat(lat) * Math.PI / 180))),
      },
      createdAt: { $gte: timeThreshold },
      status: 'active',
    }).sort({ createdAt: -1 });

    res.json({
      reports: reports.map(report => ({
        ...report.toObject(),
        distance: calculateDistance(lat, lng, report.coordinates.lat, report.coordinates.lng),
        timeElapsed: Math.floor((Date.now() - report.createdAt) / (1000 * 60)),
      })),
      meta: {
        total: reports.length,
        radius: parseInt(radius),
        timeframe: parseInt(timeframe),
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Utility functions
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lng2 - lng1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) *
    Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

async function sendNearbyAlerts(coordinates, vehicleType) {
  try {
    // Find users within 1km radius
    const nearbyUsers = await User.find({
      // This is a simplified query - in production, you'd use proper geospatial queries
    });

    let alertsSent = 0;
    
    for (const user of nearbyUsers) {
      if (user.preferences.notificationEnabled) {
        // Send push notification
        try {
          await admin.messaging().send({
            topic: `user_${user._id}`,
            notification: {
              title: 'RTO Alert',
              body: `${vehicleType} spotted nearby. Check your parking!`,
            },
            data: {
              type: 'rto_alert',
              coordinates: JSON.stringify(coordinates),
            },
          });
          alertsSent++;
        } catch (error) {
          console.error('Error sending push notification:', error);
        }

        // Send SMS if enabled
        if (user.preferences.smsAlerts && user.phone) {
          try {
            await twilioClient.messages.create({
              body: `RTO Alert: ${vehicleType} spotted nearby. Check your parking location!`,
              from: process.env.TWILIO_PHONE_NUMBER,
              to: user.phone,
            });
          } catch (error) {
            console.error('Error sending SMS:', error);
          }
        }
      }
    }

    return alertsSent;
  } catch (error) {
    console.error('Error sending alerts:', error);
    return 0;
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`RTO Alert System API server running on port ${PORT}`);
});

