import cv2
import numpy as np
from ultralytics import YOLO
import torch
import json
import requests
from datetime import datetime
import os
from typing import List, Dict, Tuple

class RTOVehicleDetector:
    """
    AI-powered RTO vehicle detection using YOLOv8
    """
    
    def __init__(self, model_path: str = 'models/yolov8_rto_custom.pt'):
        """
        Initialize the RTO vehicle detector
        
        Args:
            model_path: Path to the trained YOLOv8 model
        """
        self.model_path = model_path
        self.model = None
        self.class_names = {
            0: 'rto_patrol_car',
            1: 'rto_tow_truck',
            2: 'rto_motorcycle',
            3: 'rto_officer'
        }
        self.confidence_threshold = 0.5
        self.load_model()
    
    def load_model(self):
        """Load the YOLOv8 model"""
        try:
            if os.path.exists(self.model_path):
                self.model = YOLO(self.model_path)
                print(f"Custom RTO model loaded from {self.model_path}")
            else:
                # Fallback to general YOLOv8 model
                self.model = YOLO('yolov8n.pt')
                print("Using general YOLOv8 model - custom RTO model not found")
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = YOLO('yolov8n.pt')
    
    def detect_rto_vehicles(self, image: np.ndarray) -> List[Dict]:
        """
        Detect RTO vehicles in the given image
        
        Args:
            image: Input image as numpy array
            
        Returns:
            List of detection results
        """
        if self.model is None:
            return []
        
        try:
            # Run inference
            results = self.model(image)
            detections = []
            
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for i, box in enumerate(boxes):
                        confidence = float(box.conf[0])
                        if confidence >= self.confidence_threshold:
                            # Get bounding box coordinates
                            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                            class_id = int(box.cls[0])
                            
                            # Map to RTO-specific classes or general vehicle classes
                            class_name = self.class_names.get(class_id, f'vehicle_{class_id}')
                            
                            detection = {
                                'class': class_name,
                                'confidence': confidence,
                                'boundingBox': {
                                    'x': int(x1),
                                    'y': int(y1),
                                    'width': int(x2 - x1),
                                    'height': int(y2 - y1)
                                }
                            }
                            detections.append(detection)
            
            return detections
            
        except Exception as e:
            print(f"Error during detection: {e}")
            return []
    
    def process_image_file(self, image_path: str) -> Dict:
        """
        Process an image file and return detection results
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Detection results dictionary
        """
        try:
            # Load image
            image = cv2.imread(image_path)
            if image is None:
                return {'error': 'Could not load image'}
            
            # Detect RTO vehicles
            detections = self.detect_rto_vehicles(image)
            
            # Check if any RTO vehicles detected
            alert_generated = len(detections) > 0
            
            return {
                'detections': detections,
                'processingTime': 0.45,  # Placeholder - would be actual processing time
                'alertGenerated': alert_generated,
                'imageSize': {
                    'width': image.shape[1],
                    'height': image.shape[0]
                }
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def process_base64_image(self, base64_image: str) -> Dict:
        """
        Process a base64 encoded image
        
        Args:
            base64_image: Base64 encoded image string
            
        Returns:
            Detection results dictionary
        """
        try:
            # Decode base64 image
            import base64
            image_data = base64.b64decode(base64_image)
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                return {'error': 'Could not decode image'}
            
            # Detect RTO vehicles
            detections = self.detect_rto_vehicles(image)
            
            # Check if any RTO vehicles detected
            alert_generated = len(detections) > 0
            
            return {
                'detections': detections,
                'processingTime': 0.45,
                'alertGenerated': alert_generated,
                'imageSize': {
                    'width': image.shape[1],
                    'height': image.shape[0]
                }
            }
            
        except Exception as e:
            return {'error': str(e)}

class PredictiveAnalytics:
    """
    Predictive analytics for RTO patrol patterns and fine probability
    """
    
    def __init__(self):
        self.historical_data = []
        self.model = None
    
    def load_historical_data(self, data_path: str):
        """Load historical fine and patrol data"""
        try:
            with open(data_path, 'r') as f:
                self.historical_data = json.load(f)
        except Exception as e:
            print(f"Error loading historical data: {e}")
    
    def predict_patrol_probability(self, lat: float, lng: float, 
                                 hour: int, day_of_week: int) -> float:
        """
        Predict the probability of RTO patrol in a given area and time
        
        Args:
            lat: Latitude
            lng: Longitude
            hour: Hour of the day (0-23)
            day_of_week: Day of the week (0-6, Monday=0)
            
        Returns:
            Probability score (0-1)
        """
        # Simplified prediction logic
        # In production, this would use a trained ML model
        
        base_probability = 0.1
        
        # Higher probability during business hours
        if 9 <= hour <= 18:
            base_probability += 0.3
        
        # Higher probability on weekdays
        if day_of_week < 5:
            base_probability += 0.2
        
        # Higher probability in commercial areas (simplified)
        if self._is_commercial_area(lat, lng):
            base_probability += 0.2
        
        return min(base_probability, 1.0)
    
    def _is_commercial_area(self, lat: float, lng: float) -> bool:
        """Check if coordinates are in a commercial area"""
        # Simplified logic - in production, this would use actual area data
        return True  # Placeholder
    
    def generate_heatmap_data(self, center_lat: float, center_lng: float, 
                            radius: int = 2000) -> List[Dict]:
        """
        Generate heatmap data for fine probability in an area
        
        Args:
            center_lat: Center latitude
            center_lng: Center longitude
            radius: Radius in meters
            
        Returns:
            List of heatmap data points
        """
        heatmap_data = []
        current_hour = datetime.now().hour
        current_day = datetime.now().weekday()
        
        # Generate grid points around the center
        grid_size = 20
        lat_step = (radius / 111000) / grid_size
        lng_step = (radius / (111000 * np.cos(np.radians(center_lat)))) / grid_size
        
        for i in range(-grid_size//2, grid_size//2):
            for j in range(-grid_size//2, grid_size//2):
                lat = center_lat + i * lat_step
                lng = center_lng + j * lng_step
                
                intensity = self.predict_patrol_probability(
                    lat, lng, current_hour, current_day
                )
                
                if intensity > 0.1:  # Only include significant probabilities
                    heatmap_data.append({
                        'lat': lat,
                        'lng': lng,
                        'intensity': intensity
                    })
        
        return heatmap_data

# Flask API endpoints for AI services
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Initialize detector and analytics
detector = RTOVehicleDetector()
analytics = PredictiveAnalytics()

@app.route('/ai/detect', methods=['POST'])
def detect_rto_vehicle():
    """API endpoint for RTO vehicle detection"""
    try:
        data = request.get_json()
        
        if 'image' not in data:
            return jsonify({'error': 'Image data required'}), 400
        
        # Process the image
        result = detector.process_base64_image(data['image'])
        
        # Add coordinates if provided
        if 'coordinates' in data:
            result['coordinates'] = data['coordinates']
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/ai/heatmap/<area>', methods=['GET'])
def get_heatmap(area):
    """API endpoint for heatmap data"""
    try:
        # Parse area coordinates
        if ',' in area:
            lat, lng = map(float, area.split(','))
        else:
            return jsonify({'error': 'Invalid area format'}), 400
        
        resolution = request.args.get('resolution', 'medium')
        timeframe = int(request.args.get('timeframe', 24))
        
        # Generate heatmap data
        heatmap_data = analytics.generate_heatmap_data(lat, lng)
        
        # Find hotspots (areas with high intensity)
        hotspots = [
            {
                'lat': point['lat'],
                'lng': point['lng'],
                'radius': 200,
                'intensity': point['intensity'],
                'peakHours': ['10:00-12:00', '16:00-18:00']
            }
            for point in heatmap_data
            if point['intensity'] > 0.6
        ]
        
        return jsonify({
            'center': {'lat': lat, 'lng': lng},
            'radius': 2000,
            'resolution': resolution,
            'timeframe': timeframe,
            'heatmapData': heatmap_data,
            'hotspots': hotspots,
            'lastUpdated': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'OK',
        'service': 'RTO AI Detection Service',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

