import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(RTOAlertApp());
}

class RTOAlertApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RTO Smart Alert',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Color(0xFF1E88E5),
        accentColor: Color(0xFFFF9800),
      ),
      home: MapScreen(),
    );
  }
}

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;
  Location location = Location();
  LocationData? currentLocation;
  Set<Marker> markers = {};
  Set<Polygon> parkingZones = {};
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  @override
  void initState() {
    super.initState();
    _initializeLocation();
    _setupNotifications();
    _loadParkingZones();
  }

  void _initializeLocation() async {
    bool serviceEnabled;
    PermissionStatus permissionGranted;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) {
        return;
      }
    }

    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    currentLocation = await location.getLocation();
    setState(() {});

    location.onLocationChanged.listen((LocationData newLocation) {
      setState(() {
        currentLocation = newLocation;
      });
      _checkParkingZone(newLocation);
    });
  }

  void _setupNotifications() async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _showAlert(message.notification?.title ?? 'Alert',
          message.notification?.body ?? 'RTO Alert');
    });

    String? token = await messaging.getToken();
    print('FCM Token: $token');
  }

  void _loadParkingZones() async {
    // Simulate loading parking zones from API
    setState(() {
      parkingZones.add(
        Polygon(
          polygonId: PolygonId('legal_zone_1'),
          points: [
            LatLng(19.0760, 72.8777),
            LatLng(19.0765, 72.8777),
            LatLng(19.0765, 72.8785),
            LatLng(19.0760, 72.8785),
          ],
          fillColor: Colors.green.withOpacity(0.3),
          strokeColor: Colors.green,
          strokeWidth: 2,
        ),
      );

      parkingZones.add(
        Polygon(
          polygonId: PolygonId('no_parking_zone_1'),
          points: [
            LatLng(19.0770, 72.8790),
            LatLng(19.0775, 72.8790),
            LatLng(19.0775, 72.8798),
            LatLng(19.0770, 72.8798),
          ],
          fillColor: Colors.red.withOpacity(0.3),
          strokeColor: Colors.red,
          strokeWidth: 2,
        ),
      );
    });
  }

  void _checkParkingZone(LocationData location) {
    // Check if user is in a no-parking zone
    // This is a simplified check - in reality, you'd use proper geofencing
    double lat = location.latitude!;
    double lng = location.longitude!;

    if (lat >= 19.0770 && lat <= 19.0775 && lng >= 72.8790 && lng <= 72.8798) {
      _showAlert('Parking Alert', 'You are entering a no-parking zone!');
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _reportRTOVehicle() {
    if (currentLocation != null) {
      _sendRTOReport(currentLocation!.latitude!, currentLocation!.longitude!);
    }
  }

  void _sendRTOReport(double lat, double lng) async {
    try {
      final response = await http.post(
        Uri.parse('https://api.rtoalertsystem.com/v1/reports/rto'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'coordinates': {'lat': lat, 'lng': lng},
          'vehicleType': 'patrol_car',
          'timestamp': DateTime.now().toIso8601String(),
        }),
      );

      if (response.statusCode == 200) {
        _showAlert('Report Sent', 'RTO vehicle report submitted successfully!');
      }
    } catch (e) {
      print('Error sending report: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RTO Smart Alert'),
        backgroundColor: Color(0xFF1E88E5),
      ),
      body: currentLocation == null
          ? Center(child: CircularProgressIndicator())
          : GoogleMap(
              onMapCreated: (GoogleMapController controller) {
                mapController = controller;
              },
              initialCameraPosition: CameraPosition(
                target: LatLng(
                  currentLocation!.latitude!,
                  currentLocation!.longitude!,
                ),
                zoom: 15.0,
              ),
              markers: markers,
              polygons: parkingZones,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
            ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: _reportRTOVehicle,
            backgroundColor: Color(0xFFFF9800),
            child: Icon(Icons.report),
            heroTag: "report",
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: () {
              // Open camera for AI detection
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CameraScreen()),
              );
            },
            backgroundColor: Color(0xFF1E88E5),
            child: Icon(Icons.camera_alt),
            heroTag: "camera",
          ),
        ],
      ),
    );
  }
}

class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AI Detection'),
        backgroundColor: Color(0xFF1E88E5),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.camera_alt,
              size: 100,
              color: Color(0xFF1E88E5),
            ),
            SizedBox(height: 20),
            Text(
              'AI-powered RTO Vehicle Detection',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Point your camera at vehicles to detect RTO enforcement',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Implement camera functionality
                _showDetectionResult();
              },
              child: Text('Start Detection'),
              style: ElevatedButton.styleFrom(
                primary: Color(0xFF1E88E5),
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDetectionResult() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Detection Result'),
          content: Text('RTO Tow Truck detected with 92% confidence!'),
          actions: [
            TextButton(
              child: Text('Alert Others'),
              onPressed: () {
                Navigator.of(context).pop();
                // Send alert to other users
              },
            ),
            TextButton(
              child: Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

